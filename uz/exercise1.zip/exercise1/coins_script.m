I = imread('coins.jpg');
thld = I > threshold_otsu(rgb2gray(I));
figure; colormap gray; imagesc(thld);  axis equal; axis tight; title('closed');